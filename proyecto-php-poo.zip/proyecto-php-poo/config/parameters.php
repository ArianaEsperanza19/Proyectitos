<?php
define("base_url", "http://localhost/master-php/proyecto-php-poo/");
define("controller_default", "productoController");
define("action_default", "index");

